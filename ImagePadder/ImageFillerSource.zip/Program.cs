﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.InteropServices;

namespace ImageFiller {
    internal class Program {
        static void Main(string[] args) {

            string imagePath = args[0];
            string newImagePath = args[1];

            Grid<int> oldImage = ImageToArray((Bitmap)Image.FromFile(imagePath));

            Grid<int> newImage = new Grid<int>(
                NearestPowerOf2(oldImage.Width), 
                NearestPowerOf2(oldImage.Height)
            );

            int heightPadding0 = (newImage.Height - oldImage.Height)/2;
            int widthPadding0 = (newImage.Width - oldImage.Width)/2;
            int heightPadding1 = newImage.Height - oldImage.Height - heightPadding0;
            int widthPadding1 = newImage.Width - oldImage.Width - widthPadding0;

            // Copy center
            for (int x = 0; x < oldImage.Width; x++) {
                for (int y = 0; y < oldImage.Height; y++) {
                    newImage[widthPadding0 + x, heightPadding0 + y] = oldImage[x, y];
                }
            }

            // Top left corner
            {
                int color = oldImage[0, 0];
                for (int x = 0; x < widthPadding0; x++) {
                    for (int y = 0; y < heightPadding0; y++) {
                        newImage[x, y] = color;
                    }
                }
            }
            // Top right corner
            {
                int color = oldImage[oldImage.Width - 1, 0];
                for (int x = 0; x < widthPadding1; x++) {
                    for (int y = 0; y < heightPadding0; y++) {
                        newImage[newImage.Width - widthPadding1 + x, y] = color;
                    }
                }
            }
            // Bottom left corner
            {
                int color = oldImage[0, oldImage.Height -1];
                for (int x = 0; x < widthPadding0; x++) {
                    for (int y = 0; y < heightPadding1; y++) {
                        newImage[x, newImage.Width - heightPadding1 + y] = color;
                    }
                }
            }
            // Bottom right corner
            {
                int color = oldImage[oldImage.Width - 1, oldImage.Height - 1];
                for (int x = 0; x < widthPadding1; x++) {
                    for (int y = 0; y < heightPadding1; y++) {
                        newImage[newImage.Width - widthPadding1 + x, newImage.Width - heightPadding1 + y] = color;
                    }
                }
            }
            // Top
            for (int x=0; x < oldImage.Width; x++) {
                for (int y = 0; y < heightPadding0; y++) {
                    newImage[widthPadding0 + x, y] = oldImage[x, 0];
                }
            }
            // Bottom
            for (int x = 0; x < oldImage.Width; x++) {
                for (int y = 0; y < heightPadding1; y++) {
                    newImage[widthPadding0 + x, newImage.Height - heightPadding1 + y] = oldImage[x, oldImage.Height-1];
                }
            }
            // Left
            for (int x = 0; x < widthPadding0; x++) {
                for (int y = 0; y < oldImage.Height; y++) {
                    newImage[x, heightPadding0 + y] = oldImage[0, y];
                }
            }
            // Right
            for (int x = 0; x < widthPadding1; x++) {
                for (int y = 0; y < oldImage.Height; y++) {
                    newImage[newImage.Width - widthPadding1 + x, heightPadding0 + y] = oldImage[oldImage.Width-1, y];
                }
            }

            Image newImageImage = ArrayToImage(newImage);
            newImageImage.Save(newImagePath);
        }
        public static Bitmap ArrayToImage(Grid<int> array) {
            // Copy into bitmap
            Bitmap bitmap = new Bitmap(array.Width, array.Height);

            for (int x = 0; x < array.Width; x++) {
                for (int y = 0; y < array.Height; y++) {
                    bitmap.SetPixel(x, y, Color.FromArgb(array[x, y]));
                }
            }
            return bitmap;
        }

        public static Grid<int> ImageToArray(Bitmap bmp) {
            // Slow but I give up
            int width = bmp.Width;
            int height = bmp.Height;
            Grid<int> pixels = new Grid<int>(width, height);

            for (int x = 0; x < width; x++) {
                for (int y = 0; y < height; y++) {
                    Color pixel = bmp.GetPixel(x, y);
                    pixels[x, y] = pixel.ToArgb();
                }
            }
            return pixels;
        }

        public static int NearestPowerOf2(int number) {
            return (int)Math.Pow(2, Math.Ceiling(Math.Log(number, 2)));
        }
    }
}
